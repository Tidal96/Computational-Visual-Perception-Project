Eight experimental preview pairs, not the final project submission.
Original and Mooney PNGs are 1024 x 1024.
See parameters.csv for settings and ATTRIBUTION.md for photographers and image licenses.
